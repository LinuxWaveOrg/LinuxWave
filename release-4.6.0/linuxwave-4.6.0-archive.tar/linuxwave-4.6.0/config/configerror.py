#!/usr/bin/env python3

# configerror.py

import sys
import subprocess

from configpaths import config_dir_candidates, find_config_dir


# -------------------- 颜色定义 --------------------

RED_BOLD = '\033[1;31m'
YELLOW = '\033[33m'
RESET = '\033[0m'


# -------------------- 运行期依赖 --------------------

REQUIRED_MODULES = (
    ("requests", "HTTPS 请求"),
    ("packaging", "版本号比较"),
    ("rich", "下载进度条"),
)


def check_dependencies():
    # 在真正分发命令之前检查第三方依赖。
    # 换过解释器（apt/pyenv/Homebrew 升级 python3）之后，这些包往往还留在旧那个
    # 解释器下，命令会以各种奇怪的方式失败 —— 提前拦住并给出可执行的修复命令，
    # 比让某个子模块在导入阶段报「模块不可用」清楚得多。
    #
    # 正常情况下根本走不到这里：lib/wave 启动器会先挑一个真能 import 的解释器。
    # 这一层是兜底（例如用户绕过启动器、直接用 python3 lib/wave.py 调用）。

    missing = []
    for name, purpose in REQUIRED_MODULES:
        try:
            __import__(name)
        except ImportError:
            missing.append(f"{name}（{purpose}）")

    if not missing:
        return

    print(f"{RED_BOLD}🌊 Error: Missing Python dependencies: {', '.join(missing)}.{RESET}")
    print(f"{RED_BOLD}🌊 The current interpreter cannot run LinuxWave:{RESET}")
    print(f"{YELLOW}   {sys.executable}{RESET}")
    print(f"{RED_BOLD}🌊 Install them and try again:{RESET}")
    print(f"{YELLOW}   {sys.executable} -m pip install requests packaging rich{RESET}")
    print(f"{YELLOW}🌊 Or reinstall LinuxWave so it uses its own bundled Python:{RESET}")
    print(f"{YELLOW}   /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/LinuxWaveOrg/LinuxWave/HEAD/lib/install.sh)\"{RESET}")
    sys.exit(1)


# -------------------- 环境检测与报错 --------------------

def check_environment():
    
    # 检测当前环境
    # - 如果 /etc/linuxwave_config/config.json 或 ~/.config/linuxwave_config/config.json
    #   存在，说明已正式安装，正常继续。
    # - 如果都不存在，且当前在 git 仓库里，报错并退出。

    if find_config_dir() is not None:
        return

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0 or result.stdout.strip() != "true":
            return
    except Exception:
        return

    try:
        shallow_result = subprocess.run(
            ["git", "rev-parse", "--is-shallow-repository"],
            capture_output=True, text=True, timeout=5
        )
        is_shallow = shallow_result.stdout.strip() == "true"
    except Exception:
        is_shallow = False

    try:
        root_result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5
        )
        repo_root = root_result.stdout.strip()
    except Exception:
        repo_root = ""

    if is_shallow:
        print(f"{RED_BOLD}🌊 Error: LinuxWave is a shallow clone!{RESET}")
    else:
        print(f"{RED_BOLD}🌊 Error: LinuxWave is a git clone!{RESET}")

    config_paths = " or ".join(str(directory / "config.json") for directory in config_dir_candidates())

    print("")
    print(f"LinuxWave is not distributed as a shallow clone. Instead, it uses install.sh to download various files to their corresponding locations. Among other things, install.sh writes a configuration file to {config_paths}. This configuration file records a large amount of information, including the location where you downloaded LinuxWave, and it is called by many programs. Without it, many programs will not be able to find the directories.")
    print("")
    if is_shallow:
        print("We have detected that you are using a shallow clone, which will cause LinuxWave to fail to work properly. To continue using it, please run $ /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/LinuxWaveOrg/LinuxWave/HEAD/lib/install.sh)\" and select the directory you want to install to. You can also run $ bash " + repo_root + "/lib/install.sh or $ /bin/bash " + repo_root + "/lib/install.sh and select the directory you want to install to in order to fully install LinuxWave.")
    else:
        print("We have detected that you are using a git clone, which will cause LinuxWave to fail to work properly. To continue using it, please run $ /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/LinuxWaveOrg/LinuxWave/HEAD/lib/install.sh)\" and select the directory you want to install to. You can also run $ bash " + repo_root + "/lib/install.sh or $ /bin/bash " + repo_root + "/lib/install.sh and select the directory you want to install to in order to fully install LinuxWave.")
    print("")
    print("If you are a collaborator of LinuxWave, or if you cloned the source code for a specific purpose, please do not run it locally, or at least do not run it in the Git directory.")
    print("")
    print("If you have any other questions, please contact hi@macwave.org.")

    sys.exit(1)


if __name__ == "__main__":
    print("🌊 This module is not meant to be run directly.")
    print("🌊 It is used internally by wave.py.")
    sys.exit(1)