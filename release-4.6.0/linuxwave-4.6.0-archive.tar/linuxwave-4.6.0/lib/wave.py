#!/usr/bin/env python3

# wave.py

import importlib
import sys
from pathlib import Path

# configerror 要在读到 base_dir **之前**就跑（它判断的正是「这台机器装了没」），
# 所以这几个目录只能按脚本自身的位置推 —— 安装树与仓库里，lib/ 与 cli/、
# config/ 都是同级目录，两种情形同一条规则。
HERE = Path(__file__).resolve().parent      # <base_dir>/lib
ROOT = HERE.parent                          # <base_dir>

sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "config"))
sys.path.insert(0, str(ROOT / "cli"))

try:
    from configerror import check_environment, check_dependencies
    check_environment()
    check_dependencies()

    # -------------------- 配置与模块路径 --------------------

    from configpaths import load_base_dir
except ModuleNotFoundError as exc:
    # 安装树不完整（少了一个模块）。这种情况**必须给一条能照做的命令**，不能甩
    # 一句 traceback：wave 起不来，患者手里就只剩 install.sh。
    print(f"🌊 Error: this LinuxWave installation is incomplete: {exc}", file=sys.stderr)
    print(f"🌊 At        {Path(__file__).resolve()}", file=sys.stderr)
    print("🌊 Next      reinstall it (nothing you installed will be removed):", file=sys.stderr)
    print('🌊             /bin/bash -c "$(curl -fsSL '
          'https://raw.githubusercontent.com/LinuxWaveOrg/LinuxWave/HEAD/lib/install.sh)"',
          file=sys.stderr)
    sys.exit(1)

BASE_DIR = load_base_dir()
CLI_DIR = BASE_DIR / "cli"
CONFIG_DIR = BASE_DIR / "config"
LIB_DIR = BASE_DIR / "lib"
NET_DIR = BASE_DIR / "net"
PKG_DIR = BASE_DIR / "pkg"
SURFBOARD_DIR = BASE_DIR / "surfboard"

# 顺序与 scripts/components.txt 一致。逆序 insert 才会得到那个顺序：每次 insert(0)
# 都插在最前面，所以最后插入的排在首位。cli/ 与 config/ 因此压在 lib/ 之上 ——
# 从旧版本升级上来的树里可能还留着 lib/configerror.py 之类的旧副本，不能让它们
# 盖住新模块。
for _component in (SURFBOARD_DIR, PKG_DIR, NET_DIR, LIB_DIR, CONFIG_DIR, CLI_DIR):
    sys.path.insert(0, str(_component))
del _component

# 放在顶层：「未知命令」那条分支也要用它们，而那条分支在分发之前。
#   commands —— 子命令元数据（唯一来源，见 cli/commands.py）
#   silent   —— 静默旗标的解析与应用
#   suggest  —— 命令名打错时的纠错建议
import commands as commands_module
import silent
import suggest as suggest_module


# -------------------- 主调度逻辑 --------------------

def main():
    words = sys.argv[1:]

    # 1. 无任何输入
    if not words:
        from help import print_custom_help
        print_custom_help()
        sys.exit(0)

    # 先算一次静默状态：下面「命令不存在」的分支也要用它，
    # 而 words 的正式剥离发生在 COMMANDS 分支内（那里的 words 才是给 handler 的）。
    #
    # 取首词也从剥离后的副本里取：`wave -s update jq` 里的 -s 是全局旗标，
    # 不该被当成命令名报「unknown command: -s」。
    lead, is_silent, _show_error = silent.strip(words)
    FirstWord = lead[0] if lead else words[0]

    # 2. 参数优先
    if FirstWord in ("-h", "--help"):
        from help import print_custom_help
        print_custom_help()
        sys.exit(0)
    if FirstWord in ("-V", "--version"):
        from help import print_version
        print_version()
        sys.exit(0)

    # 3. 命令分发
    entry = commands_module.get(FirstWord)
    if entry is not None:
        # 公共旗标（--proxy / --skip-ssl / 三档超时 / -v / -C …）只解析一次，
        # 入口是 cli/common.py —— 各 handler 拿到的值、报错文案与退出码因此一致。
        # 解析放在分发之前：取值不合法时，任何命令都是同一句错。
        import common
        options = common.parse(words)

        # `--proxy` 必须对这条命令的**所有**请求生效，不只是下载包体那一步。
        # 做法是把值写进进程环境（HTTPS_PROXY 等），因为 requests（trust_env 默认开）、
        # urllib 与 bash 子脚本里的 curl 都读环境变量 —— 一处生效，全部覆盖。
        common.apply_proxy(options)

        # `--skip-ssl` 在这里只**记录**，真正生效要等确认之后（见 net/tls.py）。
        import tls
        tls.configure(options.skip_ssl)
        if FirstWord not in ("install", "upgrade"):
            tls.grant()

        # `-s / --silent`（含 `-sS`）：剥掉旗标并落到运行期开关。
        # 为什么必须**从 argv 里拿掉**：各 handler 的旗标白名单里没有它们，
        # 留着的话 `wave install jq -s` 会报「illegal option -s」。
        words = silent.apply(words, FirstWord)

        # `wave <command> -h|--help`：打印该命令自己的用法后退出。
        # 必须在这里拦下：各 handler 的旗标白名单里没有 --help，
        # 否则它会被当作未知旗标忽略（selfupdate 甚至直接开始自更新）。
        if any(word in ("-h", "--help") for word in words[1:]):
            from help import print_command_help
            print_command_help(FirstWord)
            sys.exit(0)

        # 处理函数也来自元数据：命令表里写的是 `模块.函数`，这里只负责 import 与调用。
        # 没有第二条 if/elif 链要维护，也就没有「表里有、链上没有」这种静默成功。
        full_input = "wave " + " ".join(words)
        handler = getattr(importlib.import_module(entry.module), entry.handler)
        result = handler(full_input) if entry.takes_input else handler()
        # 处理函数自己的 sys.exit 照旧优先；走到这里说明它正常返回了，
        # 返回值就是退出码（shellenv / manual 会用它）。
        sys.exit(result)

    # 4. 未知输入
    #
    # 静默模式下不能印整篇帮助（那是噪音，而且脚本要的是可匹配的一行）。
    # 但命令写错必须让人知道 —— 否则 `wave update jq -s` 会一声不响地失败。
    #
    # 命令名写错时，旗标根本轮不到校验 —— 于是 `wave update jq --unkown-flag`
    # 只会说「update 不是命令」，把那条拼错的旗标一起吞了。而「建议」还会把
    # 它原样抄进去，用户照着改仍然错。所以这里单独查一遍：
    # 不在任何命令白名单里的旗标，一并报出来。
    import flags as flags_module
    bad_flags = flags_module.unknown_flags(words)

    if is_silent:
        silent.unknown("command", FirstWord)
        sys.exit(1)

    # 建议里不能留着坏旗标 —— 否则「Did you mean: wave upgrade jq --unkown-flag」
    # 抄给用户一条还是错的命令，他照着改会再撞一次同样的错。
    hint = suggest_module.command(words, commands_module.dispatch_table())
    if hint and bad_flags:
        fixed, wrong, right = hint
        kept = [w for w in fixed.split() if not set(flags_module.split(w)) & set(bad_flags)]
        hint = (" ".join(kept), wrong, right)

    from help import print_error_help
    print_error_help(hint, unknown_flags=bad_flags, argv=sys.argv)
    sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        # 下载卡住时用户多半会按 Ctrl-C。默认行为是把整个调用栈打出来，
        # 那对用户毫无用处，也不像一次「正常中止」。
        print("", file=sys.stderr)
        print("🌊 Interrupted. Nothing was installed.", file=sys.stderr)
        sys.exit(130)
    except BrokenPipeError:
        # 例如 `wave list | head`：下游提前关掉管道时安静退出
        sys.exit(0)
